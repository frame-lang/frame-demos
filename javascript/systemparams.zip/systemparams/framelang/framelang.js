class FrameEvent {
    constructor(message, params) {
      this.message = message;
      this.params = params;
      
    }
    return = null;
  }

module.exports =  new FrameEvent;